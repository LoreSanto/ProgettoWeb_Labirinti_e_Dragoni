"use strict";

document.addEventListener('DOMContentLoaded', () => {
    const productList = document.querySelector('.prod-gadget');
    const loadMoreButton = document.getElementById('loadMoreButton');
    const filterForm = document.getElementById('filterForm');
    const category = 'gadget';
    let offset = 0;
    const limit = 9;
    let filters = {};

    let reloadFilter = 0; //variabile che si modifica qualora attivassi il filtro (evita bug di elemento singolo schiacciato)

    const loadProducts = () => {
        const params = new URLSearchParams({ limit, offset, ...filters });
        fetch(`/api/products/${category}?${params.toString()}`)
            .then(response => response.json())
            .then(products => {
                if (products.length > 0) {
                    offset += products.length;
                    products.forEach((product, index) => {
                        const productElement = document.createElement('div');
                        productElement.className = 'col-lg-4 col-12 mb-3 prod-gadget';

                        // Layout per uno singolo prodotto
                        if (products.length === 1 && reloadFilter ===1) {
                            productElement.classList.add('single-product'); // Aggiunta classe per lo stile singolo. Da vedere poi altre eventuali zoluzioni   

                            reloadFilter=0;   
                        }

                        const specialLabelHtml = product.special_label.trim() === '' ? '' : `
                            <div class="product-top d-flex">
                                <span class="product-alert">${product.special_label}</span>
                            </div>
                        `;

                        productElement.innerHTML = `
                            <div class="product-thumb">
                                <a href="/product/${product.id}">
                                    <img src="/images/${product.img}" class="img-fluid product-image ingrandimento" alt="${product.nome}">
                                </a>
                                ${specialLabelHtml}
                                <div class="product-info d-flex">
                                    <div class="prod-title-padding">
                                        <h5 class="prod-title">${product.nome}</h5>
                                        <p class="prod-p text-muted">${product.descrizione}</p>
                                    </div>
                                    <small class="prod-price text-muted ms-auto mt-auto mb-5">${product.prezzo.toFixed(2)} €</small>
                                </div>
                            </div>
                        `;
                        productList.appendChild(productElement);
                    });

                    // Gestione del pulsante "Carica di più"
                    if (products.length < limit || products.length === 0) {
                        loadMoreButton.classList.add('hidden'); // Nascondi il pulsante usando la classe
                    } else {
                        loadMoreButton.classList.remove('hidden'); // Mostra il pulsante
                    }
                } else {
                    loadMoreButton.classList.add('hidden'); // Nascondi il pulsante se non ci sono prodotti

                    //visuzlizza HTML di nessun prodotto trovato
                    productList.innerHTML = '<p>Nessun Prodotto trovato</p>';
                }
            })
            .catch(error => {
                console.error('Errore:', error);
                productList.innerHTML = '<p>Errore nel recupero dei prodotti</p>';
            });
    };

    filterForm.addEventListener('submit', (event) => {
        event.preventDefault();
        offset = 0;
        productList.innerHTML = '';
        loadMoreButton.classList.remove('hidden');
    
        const categoryFilter = filterForm.category.value;
        const priceFilter = filterForm.price.value;
        const brands = Array.from(filterForm.querySelectorAll('input[name="brand"]:checked')).map(el => el.value);
    
        reloadFilter = 1;
        filters = {
            filtro_mult: categoryFilter !== 'tutti' ? categoryFilter : null,
            price: priceFilter,
            brands: brands.length > 0 ? brands.join(',') : null
        };
        
        // Rimuovi il filtro "brands" se nessuna marca è selezionata
        if (!filters.brands) {
            delete filters.brands;
        }
    
        loadProducts();
    });

    loadMoreButton.addEventListener('click', () => {
        reloadFilter=0;  
        loadProducts();
    });

    // Carica i primi prodotti quando la pagina è pronta
    loadProducts();
});