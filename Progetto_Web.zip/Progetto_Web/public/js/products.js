"use strict"

//parte dell'index:
document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/top-products')
      .then(response => response.json())
      .then(data => {
        console.log('Dati ricevuti:', data);
  
        // Gestisci i dati per ciascuna categoria
        const categories = ['gdr', 'manga', 'gadget'];
  
        categories.forEach(category => {
          const product = data[category];
          if (product) {
            const productElement = document.querySelector(`.prod-${category}`);
            
            if (productElement) {
              const imageElement = productElement.querySelector('.product-image');
              if (imageElement) {
                imageElement.src = `/images/${product.img}`;
              }
              productElement.querySelector('.prod-title').textContent = product.nome;
              productElement.querySelector('.prod-p').textContent = product.descrizione || 'Descrizione non disponibile';//se non vi è alcuna descrizione appare questa scritta (valutare se tenere)
              productElement.querySelector('.prod-price').textContent = `${product.prezzo.toFixed(2)} €`;//in questa maniera mi da due cifre dopo la virgola
  
              const alertSpan = productElement.querySelector('.product-alert');
              if (product.special_label) {
                alertSpan.textContent = product.special_label;
                alertSpan.style.display = 'inline'; // Mostra l'etichetta
              } else {
                alertSpan.style.display = 'none'; // Nascondi l'etichetta
              }

              // Aggiungi il link alla pagina del prodotto
              const linkElement = productElement.querySelector('a.link-prod');
              if (linkElement) {
                linkElement.href = `/product/${product.id}`;
              }

            }
          }
        });
      })
      .catch(error => console.error('Errore nel recupero dei dati:', error));
  });
  