"use strict";

document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Previene l'invio del form normale

    const formData = new FormData(this);

    //associo gli id dei testi per dare il riquadro rosso quando accesso sbagiato. Le classi sono definite nel file  mystile.css
    const usernameInput = document.getElementById('regusername');
    const passwordInput = document.getElementById('regpassword');
    const mailInput = document.getElementById('regmail');

    fetch('/api/register', {
      method: 'POST',
      body: new URLSearchParams(formData),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
    .then(response => {
      if (response.ok) {
        
        usernameInput.classList.remove('input-error');
        passwordInput.classList.remove('input-error');
        mailInput.classList.remove('input-error');
        usernameInput.classList.add('input-success');
        passwordInput.classList.add('input-success');
        mailInput.classList.add('input-success');

        setTimeout(() => window.location.href = '/login.html', 1000);
      } else {
        return response.text().then(text => {
          usernameInput.classList.add('input-error');
          passwordInput.classList.add('input-error');
          mailInput.classList.add('input-error');
          usernameInput.value = '';
          passwordInput.value = '';
          mailInput.value = '';
          //alert(text); // Vedere se mettere o no
      });
      }
    })
    .then(text => {
      if (text) {
        alert(text); // Mostra l'errore se presente
      }
    })
    .catch(error => {
      console.error('Errore:', error);
    });
  });