document.getElementById('product-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(this);

    fetch('/add-product', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result.includes('success=true')) {
            alert('Prodotto aggiunto con successo!');
        } else {
            alert('Errore nell\'aggiunta del prodotto.');
        }
    })
    .catch(error => console.error('Errore:', error));
  });