"use strict";

document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');

    const username = usernameInput.value;
    const password = passwordInput.value;

    fetch('/api/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => {
        if (response.ok) {
            
            usernameInput.classList.remove('input-error');
            passwordInput.classList.remove('input-error');
            usernameInput.classList.add('input-success');
            passwordInput.classList.add('input-success');

            setTimeout(() => window.location.href = '/reserved-area', 1000);
        } else {
            // Error: show error and apply error class
            return response.text().then(text => {
                usernameInput.classList.add('input-error');
                passwordInput.classList.add('input-error');
                usernameInput.value = '';
                passwordInput.value = '';
                //alert(text); // Vedere se mettere o no
            });
        }
    })
    .catch(error => {
        console.error('Errore:', error);
        usernameInput.classList.add('input-error');
        passwordInput.classList.add('input-error');
    });
});
