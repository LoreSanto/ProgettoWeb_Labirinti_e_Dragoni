"use strict";

document.getElementById('loginButton').addEventListener('click', function(e) {
    e.preventDefault(); // Previene il comportamento predefinito del link
    
    fetch('/api/check-auth')
        .then(response => {
            if (response.status === 200) {
                // L'utente è autenticato, reindirizzalo all'area riservata
                window.location.href = '/reserved-area';
            } else {
                // L'utente non è autenticato, reindirizzalo alla pagina di login
                window.location.href = '/login.html';
            }
        })
        .catch(error => {
            console.error('Errore nella verifica dell\'autenticazione:', error);
            // Se c'è un errore nella verifica, reindirizza comunque alla pagina di login
            window.location.href = '/login.html';
        });
});