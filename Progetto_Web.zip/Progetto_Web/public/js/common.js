//Lo script serve per il colore del form quanso si sbaglia/sono giuste le credenziali
"use strict";

document.querySelectorAll('input').forEach(input => {
    input.addEventListener('focus', () => {
        input.classList.remove('input-error');
        input.classList.remove('input-success');
    });
});