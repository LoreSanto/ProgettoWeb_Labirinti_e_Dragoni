"use strict";

document.addEventListener('DOMContentLoaded', () => {
    const productId = window.location.pathname.split('/').pop();
  
    // Fetch prodotti correlati
    fetch(`/api/related-products/${productId}`)
      .then(response => response.json())
      .then(data => {
        console.log('Prodotti correlati:', data);
  
        const relatedProductsContainer = document.getElementById('related-products');
        relatedProductsContainer.innerHTML = ''; // Pulisce il contenitore
  
        data.forEach(product => {
          // Crea l'elemento per il prodotto
          const productElement = document.createElement('div');
          productElement.classList.add('col-lg-4', 'col-12', 'mb-3');
  
          // Costruisci il markup del prodotto
          let productMarkup = `
            <div class="product-thumb">
              <a class="link-prod" href="/product/${product.id}">
                <img src="/images/${product.img}" class="img-fluid product-image ingrandimento" alt="">
              </a>
          `;
  
          // Aggiunge il div.product-top solo se special_label non è vuoto
          if (product.special_label) {
            productMarkup += `
              <div class="product-top d-flex">
                <span class="product-alert">${product.special_label}</span>
              </div>
            `;
          }
  
          productMarkup += `
              <div class="product-info d-flex">
                <div class="prod-title-padding">
                  <h5 class="prod-title">${product.nome}</h5>
                  <p class="prod-p text-muted">${product.descrizione || 'Descrizione non disponibile'}</p>
                </div>
                <small class="prod-price text-muted ms-auto mt-auto mb-5">${product.prezzo.toFixed(2)} €</small>
              </div>
            </div>
          `;
  
          // Inserisci il markup nel contenitore
          productElement.innerHTML = productMarkup;
          relatedProductsContainer.appendChild(productElement);
        });
      })
      .catch(error => console.error('Errore nel recupero dei prodotti correlati:', error));
});