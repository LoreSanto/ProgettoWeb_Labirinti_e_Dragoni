"use strict";

const express = require('express');
const path = require('path');
const router = express.Router();
const db = require('../db');

const multer = require('multer');
const fs = require('fs');



// Rotta per la pagina principale
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'index.html'));
});

// Rotta per il prodotto
router.get('/product/:id', (req, res) => {
  const productId = req.params.id;
  //const isAuthenticated = req.isAuthenticated();

  db.getProductById(productId, (err, product) => {
    if (err || !product) {
      return res.status(404).send('Prodotto non trovato');
    }
    res.render('product', { 
      
      product: product,
      //isAuthenticated: isAuthenticated //vedere se da togliere

     });
  });
});

// Rotta per ottenere i prodotti più richiesti per categoria
router.get('/api/top-products', (req, res) => {
  const categories = ['gdr', 'manga', 'gadget'];
  const results = {};

  let completedRequests = 0;

  categories.forEach((category) => {
    db.getTopProductsByCategory(category, (err, product) => {
      if (err) {
        return res.status(500).json({ error: 'Errore nel recupero dei dati' });
      }
      results[category] = product;

      completedRequests++;
      if (completedRequests === categories.length) {
        res.json(results);
      }
    });
  });
});

// Rotta per ottenere i prodotti per categoria con limiti, offset e filtri
router.get('/api/products/:category', (req, res) => {
  const category = req.params.category;
  const limit = parseInt(req.query.limit, 10) || 9;
  const offset = parseInt(req.query.offset, 10) || 0;

  const filters = {
    filtro_mult: req.query.filtro_mult !== 'tutti' ? req.query.filtro_mult : null,
    price: req.query.price || null,
    brands: req.query.brands || null
  };

  db.getAllProductsByCategory(category, limit, offset, filters, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Errore nel recupero dei prodotti' });
    }
    res.json(rows);
  });
});

// Rotta per la ricerca dei prodotti
router.get('/api/search', (req, res) => {
  const searchTerm = req.query.q || '';
  db.searchProducts(searchTerm, (err, products) => {
    if (err) {
      return res.status(500).send('Errore nella ricerca dei prodotti');
    }
    res.render('search-results', { products, searchTerm });
  });
});

// Rotta per ottenere prodotti della stessa categoria del prodotto selezionato
router.get('/api/related-products/:id', (req, res) => {
  const productId = req.params.id;

  db.getProductById(productId, (err, product) => {
    if (err || !product) {
      return res.status(404).json({ error: 'Prodotto non trovato' });
    }

    db.getAllProductsByOnlyCategory(product.categoria, 100, 0, (err, products) => {
      if (err) {
        return res.status(500).json({ error: 'Errore nel recupero dei prodotti' });
      }

      const filteredProducts = products.filter(p => p.id !== productId);
      const shuffledProducts = filteredProducts.sort(() => 0.5 - Math.random());

      const randomProducts = shuffledProducts.slice(0, 3);

      res.json(randomProducts);
    });
  });
});









// Configura multer per il caricamento dei file
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
      const categoria = req.body.categoria;
      const uploadPath = path.join(__dirname, '../server_resource/img', categoria);
      cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
      cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

// Rotta per gestire l'invio del form
router.post('/add-product', upload.single('img'), async (req, res) => {

  const { nome, prezzo, categoria, sottotitolo = '', descrizione = '', special_label = '', marca = '', genere = ''} = req.body;
  const img = req.file ? `img/${categoria}/${req.file.originalname}` : '';

  try {
    await db.addProduct(nome, prezzo, categoria, img, sottotitolo, descrizione, special_label, marca, genere);
    console.log('Prodotto aggiunto con successo');
    res.redirect('/reserved-area');
  } catch (error) {
    console.error('Errore aggiungendo prodotto:', error);
    res.redirect('/reserved-area');
  }
});


// Rotta per eliminare un prodotto
router.post('/delete-product/:id', (req, res) => {
  const productId = req.params.id;
  db.deleteProduct(productId, (err) => {
      if (err) {
          console.error('Errore nell\'eliminazione del prodotto:', err);
          return res.status(500).send('Errore del server');
      }
      res.redirect('/reserved-area');
  });
});



//rotta gestione preordini
router.post('/preorder', (req, res) => {
  if (!req.isAuthenticated()) {
      return res.redirect('/login.html');
  }

  const userId = req.user.id;
  const productId = req.body.productId;

  // Inserisce il preordine nel database
  db.preorderProduct(userId, productId, (err) => {
      if (err) {
          console.error('Errore durante il preordine:', err);
          return res.status(500).send('Errore durante il preordine');
      }

      // Se tutto va bene, ridirige l'utente alla pagina riservata
      res.redirect('/reserved-area');
  });
});


// Rotta per la convalida di un ordine
router.post('/validate-order/:orderId', (req, res) => {
  const orderId = req.params.orderId;

  // Funzione per aggiornare lo stato dell'ordine
  db.validateOrder(orderId,(err) => {
      if (err) {
          console.error('Errore nella convalida dell\'ordine:', err);
          return res.status(500).send('Errore del server');
      }
      res.redirect('/reserved-area'); // Ricarica la pagina per mostrare gli aggiornamenti
  });
});




// Rotta per gestire i "Mi Piace"
router.post('/product/:id/like', (req, res) => {
  if (!req.isAuthenticated()) {
      return res.redirect('/login.html');
  }

  const userId = req.user.id;
  const productId = req.params.id;

  db.setLike(userId, productId, 1, (err) => {
      if (err) {
          console.error('Errore durante l\'inserimento del mi piace:', err.message);
          return res.status(500).send('Errore durante l\'inserimento del mi piace');
      }
      res.redirect(`/product/${productId}`);
  });
});

// Rotta per gestire i "Non Mi Piace"
router.post('/product/:id/dislike', (req, res) => {
  if (!req.isAuthenticated()) {
      return res.redirect('/login.html');
  }

  const userId = req.user.id;
  const productId = req.params.id;

  db.setLike(userId, productId, -1, (err) => {
      if (err) {
          console.error('Errore durante l\'inserimento del non mi piace:', err.message);
          return res.status(500).send('Errore durante l\'inserimento del non mi piace');
      }
      res.redirect(`/product/${productId}`);
  });
});


// Rotta per ottenere il conteggio di "mi piace" e "non mi piace" per un prodotto
router.get('/api/likes-count/:id', (req, res) => {
  const productId = req.params.id;
  
  db.getLikesCountsByProductId(productId, (err, counts) => {
    if (err) {
      return res.status(500).json({ error: 'Errore nel recupero dei conteggi' });
    }
    res.json(counts);
  });
});



module.exports = router;
