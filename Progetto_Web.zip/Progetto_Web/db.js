// db.js
// Questo modulo gestisce la connessione e le query al database SQLite
"use strict";

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');

const dbPath = path.join(__dirname, 'server_resource', 'database.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Errore di connessione al database:', err.message);
  } else {
    console.log('Connesso al database SQLite.');
  }
});

// Configurazione per bcrypt
const saltRounds = 10;

// Funzione per ottenere i prodotti per categoria con filtri, limite e offset
const getAllProductsByCategory = (category, limit, offset, filters, callback) => {
  let query = `
      SELECT * FROM Prodotti
      WHERE categoria = ?`;

  const params = [category];

  if (filters.filtro_mult && filters.filtro_mult !== 'null') {
    query += ' AND filtro_mult = ?';
    params.push(filters.filtro_mult);
  }

  if (filters.price) {
    switch (filters.price) {
      case 'under5': query += ' AND prezzo < 5'; break;
      case 'under10': query += ' AND prezzo < 10'; break;
      case 'under20': query += ' AND prezzo < 20'; break;
      case 'under30': query += ' AND prezzo < 30'; break;
      case 'under40': query += ' AND prezzo < 40'; break;
      case '20-50': query += ' AND prezzo BETWEEN 20 AND 50'; break;
      case 'over50': query += ' AND prezzo > 50'; break;
    }
  }

  if (filters.brands) {
    const brandFilters = filters.brands.split(',').map(() => '?').join(',');
    query += ` AND marca IN (${brandFilters})`;
    params.push(...filters.brands.split(','));
  }

  query += `
      ORDER BY ordinati DESC
      LIMIT ? OFFSET ?`;

  params.push(limit, offset);

  db.all(query, params, (err, rows) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, rows);
    }
  });
};

// Funzione per ottenere i prodotti per categoria senza filtri
const getAllProductsByOnlyCategory = (category, limit, offset, callback) => {
  const query = `
    SELECT * FROM Prodotti
    WHERE categoria = ?
    ORDER BY ordinati DESC
    LIMIT ? OFFSET ?`;

  db.all(query, [category, limit, offset], (err, rows) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, rows);
    }
  });
};

// Funzione per ottenere il prodotto più ordinato per categoria
const getTopProductsByCategory = (category, callback) => {
  const query = `
    SELECT * FROM Prodotti
    WHERE categoria = ?
    ORDER BY ordinati DESC
    LIMIT 1`;

  db.get(query, [category], (err, row) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, row);
    }
  });
};

// Funzione per ottenere un prodotto per ID
const getProductById = (id, callback) => {
  const query = `
    SELECT * FROM Prodotti 
    WHERE id = ?`;

  db.get(query, [id], (err, row) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, row);
    }
  });
};

// Funzione per cercare prodotti per nome
const searchProducts = (searchTerm, callback) => {
  const query = `
    SELECT * FROM Prodotti
    WHERE LOWER(nome) LIKE LOWER(?)
    ORDER BY ordinati DESC`;

  db.all(query, [`%${searchTerm.trim()}%`], (err, rows) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, rows);
    }
  });
};

// Funzione per ottenere un utente per username
const getUserByUsername = (username, callback) => {
  const query = 'SELECT * FROM Users WHERE username = ?';
  db.get(query, [username], (err, row) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, row);
    }
  });
};

// Funzione per registrare un nuovo utente
const registerUser = (username, passwd, mail, callback) => {
  bcrypt.hash(passwd, saltRounds, (err, hashedPassword) => {
    if (err) {
      return callback(err);
    }
    const query = 'INSERT INTO Users (username, passwd, mail, privilegi) VALUES (?, ?, ?, ?)';
    const params = [username, hashedPassword, mail, 'user'];

    db.run(query, params, function(err) {
      callback(err, this.lastID);
    });
  });
};

// Funzione per ottenere un utente per ID
const getUserById = (id, callback) => {
  const query = 'SELECT * FROM Users WHERE id = ?';
  db.get(query, [id], (err, row) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, row);
    }
  });
};

// Funzione per chiudere il database
const closeDb = () => {
  db.close((err) => {
    if (err) {
      console.error('Errore nella chiusura del database:', err.message);
    } else {
      console.log('Database SQLite chiuso.');
    }
  });
};



//funzione per aggiungere prodotti nel DB. In questo caso ho semplificato la procedura senza l'utilizzo del calback 
const addProduct = (nome, prezzo, categoria, img, sottotitolo = '', descrizione = '', special_label = '', marca='', genere='') => {
  return new Promise((resolve, reject) => {
    const query = `
      INSERT INTO Prodotti (nome, prezzo, categoria, img, descrizione, more_info, special_label, marca, filtro_mult)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    db.run(query, [nome, prezzo, categoria, img, sottotitolo, descrizione, special_label, marca, genere], function(err) {
      if (err) {
        return reject(err);
      }
      resolve(this.lastID);
    });
  });
};


// Funzione per ottenere tutti i prodotti
const getAllProducts = (callback) => {
  const query = `SELECT * FROM Prodotti ORDER BY nome ASC`;
  db.all(query, [], (err, rows) => {
      if (err) {
          console.error('Errore nella query:', err.message);
          callback(err, null);
      } else {
          callback(null, rows);
      }
  });
};

// Funzione per eliminare un prodotto per ID
//Ho preferito gestire manualmente la cancellazione degli ordini con una eliminazione a cascata piuttosto che usare dei trigger
const deleteProduct = (id, callback) => {

  // Prima elimina gli ordini associati
  const deleteOrdersQuery = `DELETE FROM Ordinano WHERE prodotto_id = ?`;
  db.run(deleteOrdersQuery, [id], (err) => {
    if (err) {
      console.error('Errore nell\'eliminazione degli ordini:', err.message);
      return callback(err);
    }
    
    // Poi elimina il prodotto
    const deleteProductQuery = `DELETE FROM Prodotti WHERE id = ?`;
    db.run(deleteProductQuery, [id], function(err) {
      if (err) {
        console.error('Errore nell\'eliminazione del prodotto:', err.message);
        callback(err);
      } else {
        callback(null);
      }
    });
  });
};


// Funzione per la gestione dei preordini
const preorderProduct = (userId, productId, callback) => {
  const query = `
      INSERT INTO Ordinano (user_id, prodotto_id)
      VALUES (?, ?)`;

  db.run(query, [userId, productId], function(err) {
      if (err) {
          console.error('Errore durante l\'inserimento del preordine:', err.message);
          return callback(err);
      }

      // Incrementa il numero di preordini per il prodotto
      const updateQuery = `
          UPDATE Prodotti
          SET ordinati = ordinati + 1
          WHERE id = ?`;

      db.run(updateQuery, [productId], function(err) {
          if (err) {
              console.error('Errore durante l\'aggiornamento dei preordini:', err.message);
              return callback(err);
          }

          callback(null);
      });
  });
};


// Funzione per ottenere gli ordini in attesa di un determinato utente
const getPendingOrdersByUser = (userId, callback) => {
  //lo stato dell'ordine l'ho imposto direttamente nelle pagina per non avere troppe query
  const query = `
      SELECT O.id, P.nome, O.stato_ordine, O.data_ordine, P.img
      FROM Ordinano O
      JOIN Prodotti P ON O.prodotto_id = P.id
      WHERE O.user_id = ?
      ORDER BY data_ordine ASC
  `;
  db.all(query, [userId], (err, rows) => {
      if (err) {
          return callback(err);
      }
      callback(null, rows);
  });
}

// Funzione per ottenere tutti gli ordini (per gli admin) che devono essere convalidati
const getAllOrders = (callback) => {
  const query = `
      SELECT O.id, P.nome, O.stato_ordine, O.data_ordine, U.username, P.img
      FROM Ordinano O
      JOIN Prodotti P ON O.prodotto_id = P.id
      JOIN Users U ON O.user_id = U.id
      WHERE O.stato_ordine = 'In preparazione'
  `;
  db.all(query, (err, rows) => {
      if (err) {
          return callback(err);
      }
      callback(null, rows);
  });
}

// Funzione per convalidare un ordine
const validateOrder = (orderId, callback) => {
  const query = `
      UPDATE Ordinano
      SET stato_ordine = 'Convalidato',  data_ordine = datetime('now', '+14 days')
      WHERE id = ?
  `;
  db.run(query, [orderId], (err) => {
      if (err) {
          return callback(err);
      }
      callback(null);
  });
};


//al posto del triger ho inserito questa query che viene eseguita da server.js ogni minuto (poi da cambiare orario)
//infatti cancellerà in automatico i prodotti che non sono più in validità di ritiro
const removeExpiredOrders = (callback) => {
  const query = `
    DELETE FROM Ordinano
    WHERE stato_ordine = 'Convalidato' AND data_ordine <= date('now')
  `;

  db.run(query, function(err) {
    if (err) {
      console.error('Errore nella rimozione degli ordini scaduti:', err.message);
      callback(err);
    } else {
      console.log('Ordini scaduti rimossi con successo');
      callback(null);
    }
  });
};


// Funzione per inserire o aggiornare un Mi Piace o Non Mi Piace + aggiunta numero recensioni del prodotto (voti)
const setLike = (userId, productId, likeStatus, callback) => {
  const query = `
      INSERT INTO Likes (user_id, product_id, like_status)
      VALUES (?, ?, ?)
      ON CONFLICT(user_id, product_id) DO UPDATE SET like_status = ?`;

  db.run(query, [userId, productId, likeStatus, likeStatus], function(err) {
      if (err) {
          console.error('Errore durante l\'inserimento del like:', err.message);
          callback(err);
      }

      const updateQuery = `
        UPDATE Prodotti
        SET valutazioni = (
            SELECT COUNT(*)
            FROM Likes
            WHERE product_id = Prodotti.id
        )
        WHERE id = ?`;
      
      db.run(updateQuery, [productId], function(err){
        if(err) {
            console.error('Errore durante l\'update delle valutazioni:',err.message);
            callback(err);
        }

        callback(null);


      });
      
  });
};



// Funzione per ottenere il conteggio di "mi piace" e "non mi piace" per un prodotto
const getLikesCountsByProductId = (productId, callback) => {
  const query = `
    SELECT
      SUM(CASE WHEN like_status = 1 THEN 1 ELSE 0 END) AS likes_count,
      SUM(CASE WHEN like_status = -1 THEN 1 ELSE 0 END) AS dislikes_count
    FROM Likes
    WHERE product_id = ?
  `;
  
  db.get(query, [productId], (err, row) => {
    if (err) {
      console.error('Errore nella query:', err.message);
      callback(err, null);
    } else {
      callback(null, row);
    }
  });
};




// Esporta le funzioni
module.exports = {
  getAllProductsByCategory,
  getAllProductsByOnlyCategory,
  getTopProductsByCategory,
  getProductById,
  searchProducts,
  getUserByUsername,
  registerUser,
  getUserById,

  addProduct,

  getAllProducts,
  deleteProduct,

  preorderProduct,

  getPendingOrdersByUser,
  getAllOrders,

  validateOrder,

  removeExpiredOrders,

  setLike,

  getLikesCountsByProductId,

  closeDb
};
