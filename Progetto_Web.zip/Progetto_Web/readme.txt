Questo progetto è stato sviluppato da Lorenzo Santosuosso (20050494) mediante npm da terminale Powershell e Visual Studio Code.
Leggere questa piccola documentazione prima di procedere con l'esecuzione.


Link video su youtube: https://youtu.be/4ioPLdO58ek

Nel caso ci fossero problemi con l'apertura del video 
si può vedere/scaricare anche nel mio account di Mega: https://mega.nz/file/J9FWCTzK#c0hDHQ030CWHMpX7JAGzdXGBItWzgLj6YwganR0CWg0


INSTALLAZIONE AMBIENTE:


L'aplicazione è stata eseguita mediante Windows Powershell (Windows 11). 
Per installare il tutto (quindi da node.js da terminale) eseguire le procedure sotto elencate:

    Installazione node.js da terminale:

        1-Premere pulsante destro del mouse su start ed aprire il terminale da amministratore.(Su windows 10 è chiamato Windows Powershell),
        In seguito eseguire i comandi che non sono preceduti dal simbolo di commento #.

                # installs fnm (Fast Node Manager)
                winget install Schniz.fnm

                # configure fnm environment
                fnm env --use-on-cd | Out-String | Invoke-Expression

                # download and install Node.js
                fnm use --install-if-missing 14

        2-Verificare che l'installazione sia andata a buon fine:

                # verifies the right Node.js version is in the environment
                node -v # should print `v14.21.3`

                # verifies the right npm version is in the environment
                npm -v # should print `6.14.18`



    Nel caso il progetto avesse problemi a partire/dia errori nel'esecuzioni è consigliato reinstallare le dipendenze di npm :


        1-Aprire la cartella Progetto_Web (nulla va spostato da questa cartella) ed eliminare solamente cartella e file:
            /node_modules
            package-lock.json
            package.json

        2-Dopodichè eseguire nella cartella Progetto_Web:

            npm init

            npm install express morgan express-session ejs passport passport-local sqlite3 bcrypt multer node-schedule

        Per npm install consiglio di installarne 2 o 3 per volta per evitare eventuali problemi/errori durante l'installazione

        3-Una volta fatto tutto ciò si può avviare il progetto mediante :

            node ./server.js


    ATTENZIONE:

    Personalmente mi si sono verificati due tipi di errori nel corso della progettazione.

    Il primo è stato il più semplice da mettere a posto e riguarda la possibilità di avere un processo in BG sulla porta scelta per hostare il sito.
        Le opzioni sono due:
            Cambiare porta (anche se personalmente non ho provato quest'approccio)
            Semplicemente chiudere il processo che è in esecuzione (provato e funzionante)
        Per quanto riguarda il secondo approccio basterà eseguire i comandi seguenti cambiando <PID> con il PID del processo in esecuzione, 
        nel nostro caso, sulla porta 3000:

            #visualizziamo processo/i in esecuzione sulla porta 3000
            netstat -aon | findstr :3000

            #terminiamo l'esecuzione di quel processo
            taskkill /PID <PID> /F

    Il secondo errore riguarda un problema di "tenere in memoria" la configurazione di fnm. In pratica, nonostante abbiamo installato node.js ecc,
    c'è la possibilità che eseguendo il comando node ./server.js, non venga riconosciuto dal terminale.
    Volendo si può risolvere mettendo mano alle diperndenze di file .json di windows, ma per evitare di toccare qualcosa di sbagliato semplicemente
    ogni volta che si avvia il terminale basterà riconfigurare fnm con il seguente comando:

        fnm env --use-on-cd | Out-String | Invoke-Expression

    Io per sicurezza l'ho sempre eseguito nella cartella del progeto, anche se non dovrebbe cambiare nulla.


------------------------------------------------------------------------


LOGIN:

Sono presenti già diversi utenti utilizzati nella fase di test.

    -Per l'admin c'è solo un utente fissato direttamente da codice:

        nome: Admin
        password: 1234

    -Mentre per gli user si può usare quello già creato oppure crearne uno nuovo:

        nome: kira
        password: 1234

(le password sono semplici perchè avevo paura di dimenticarle)

---------------------------------------------------------------------------

cartella mia personale di progettazione:

cd .\Desktop\Università\Progetto_Web\


----------------------------APPUNTI PERSONALI------------------------------



