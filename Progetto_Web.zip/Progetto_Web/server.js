// server.js
"use strict";

const express = require('express');
const path = require('path');
const morgan = require('morgan');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const db = require('./db');
const pageRoutes = require('./routes/page');
const bcrypt = require('bcrypt');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('tiny'));

app.use(express.static(path.join(__dirname, 'public')));
app.use('/images', express.static(path.join(__dirname, 'server_resource')));

app.use(session({
  secret: 'noamfuvkasopewk',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24,
    sameSite: 'lax'
  }
}));

app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(
  (username, password, done) => {
    db.getUserByUsername(username, (err, user) => {
      if (err) return done(err);
      if (!user) return done(null, false, { message: 'Credenziali errate' });

      bcrypt.compare(password, user.passwd, (err, result) => {
        if (err) return done(err);
        if (!result) return done(null, false, { message: 'Credenziali errate' });
        return done(null, user);
      });
    });
  }
));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  db.getUserById(id, (err, user) => {
    done(err, user);
  });
});

// Rotta per il login
app.post('/api/login', passport.authenticate('local', {
  successRedirect: '/reserved-area',
}));


// Rotta per la pagina riservata + passa i prodotti in base a se admin oppure no
app.get('/reserved-area', (req, res) => {
    if (req.isAuthenticated()) {
        if (req.user.privilegi === 'admin') {

          db.getAllProducts((err, products) => {
            if (err) {
                console.error('Errore nel recupero dei prodotti:', err);
                return res.status(500).send('Errore del server');
            }

            // Recupera tutti gli ordini
            db.getAllOrders((err, allOrders) => {
                if (err) {
                    console.error('Errore nel recupero degli ordini:', err);
                    return res.status(500).send('Errore del server');
                }

                // Passa sia i prodotti che gli ordini alla vista
                res.render('reserved-area', { 
                    user: req.user, 
                    products: products, 
                    orders: allOrders 
                });
            });
          });

        } else {
          //in questo caso è un user
          
          // Recupera gli ordini per l'utente
            db.getPendingOrdersByUser(req.user.id, (err, orders) => {
                if (err) {
                    console.error('Errore nel recupero degli ordini:', err);
                    return res.status(500).send('Errore del server');
                }

                // Filtra gli ordini in base allo stato, questo servirà per vedere se ci sono o no i prodotti nelle due "cronologie"
                const ordersInPreparation = orders.filter(order => order.stato_ordine === 'In preparazione');
                const ordersValidated = orders.filter(order => order.stato_ordine === 'Convalidato');

                res.render('reserved-area', {
                    user: req.user,
                    ordersInPreparation,
                    ordersValidated
                });
            });
        }
    } else {
        res.redirect('/login.html');
    }
});

// Rotta per verificare se l'utente è autenticato
app.get('/api/check-auth', (req, res) => {
  if (req.isAuthenticated()) {
    res.sendStatus(200);
  } else {
    res.sendStatus(401);
  }
});

// Rotta per il logout
app.get('/logout', (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie('connect.sid');
      res.redirect('/login.html');
    });
  });
});

// Rotta per la registrazione
app.post('/api/register', (req, res) => {
  const { username, passwd, mail } = req.body;

  db.getUserByUsername(username, (err, user) => {
    if (err) return res.status(500).send('Errore del server');
    if (user) return res.status(400).send('Username già in uso');

    db.registerUser(username, passwd, mail, (err) => {
      if (err) return res.status(500).send('Errore nella registrazione');
      res.redirect('/login.html');
    });
  });
});

// Usa il router per le altre rotte
app.use('/', pageRoutes);



const schedule = require('node-schedule');

// Pianificare il job di pulizia ogni giorno a mezzanotte '0 0 * * *', tuttavia al momento è ogni minuto per verificare il corretto funzionamento
schedule.scheduleJob('* * * * *', function() {
  db.removeExpiredOrders((err) => {
    if (err) {
      console.error('Errore durante la pulizia periodica:', err);
    }
  });
});




app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Qualcosa è andato storto!');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server in esecuzione su http://localhost:${PORT}`);
});

process.on('SIGINT', () => {
  db.closeDb();
  process.exit(0);
});
